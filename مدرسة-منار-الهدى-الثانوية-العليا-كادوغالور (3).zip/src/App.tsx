/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Home, 
  Info, 
  Bell, 
  Users, 
  UserPlus, 
  GraduationCap, 
  ClipboardList, 
  Settings, 
  HelpCircle, 
  LogOut, 
  Menu, 
  X, 
  Search, 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  Download,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  LayoutDashboard,
  Eye,
  EyeOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
import { 
  auth, 
  db, 
  googleProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword,
  signOut, 
  onAuthStateChanged, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  onSnapshot, 
  User,
  OperationType,
  handleFirestoreError
} from './firebase';

// --- Types ---
interface Student {
  id: string;
  name: string;
  father_name: string;
  class: string;
  roll_no: string;
  uid: string;
}

interface Staff {
  id: string;
  name: string;
  role: string;
  contact: string;
  uid: string;
}

interface Committee {
  id: string;
  name: string;
  role: string;
  contact: string;
  uid: string;
}

interface Announcement {
  id: string;
  title: string;
  message: string;
  date: string;
  uid: string;
}

interface Result {
  id: string;
  student_id: string;
  student_name: string;
  father_name: string;
  class: string;
  roll_no: string;
  marks: Record<string, number>;
  total: number;
  grade: string;
  max_marks: number;
  attendance: string;
  percentage: number;
  uid: string;
}

interface MadrasaClass {
  name: string;
  subjects: string[];
  class_teacher?: string;
}

interface MadrasaDetails {
  name_ar: string;
  name_en: string;
  address: string;
  contact: string;
  classes: MadrasaClass[];
}

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
      active 
        ? 'bg-emerald-800 text-gold-400 shadow-lg shadow-emerald-900/50 scale-105' 
        : 'text-emerald-100/70 hover:bg-emerald-800/30 hover:text-emerald-50'
    }`}
  >
    <Icon size={20} className={active ? 'text-gold-400' : ''} />
    <span className="font-medium">{label}</span>
    {active && <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-gold-400" />}
  </button>
);

const Card = ({ children, title, subtitle, icon: Icon, ...props }: { children: React.ReactNode, title?: string, subtitle?: string, icon?: any, [key: string]: any }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-white/90 backdrop-blur-md border border-emerald-100 rounded-3xl p-6 shadow-xl shadow-emerald-900/5"
    {...props}
  >
    {(title || Icon) && (
      <div className="flex items-center gap-4 mb-6">
        {Icon && <div className="p-3 bg-emerald-50 rounded-2xl text-emerald-700"><Icon size={24} /></div>}
        <div>
          {title && <h3 className="text-xl font-bold text-emerald-900">{title}</h3>}
          {subtitle && <p className="text-sm text-emerald-600/70">{subtitle}</p>}
        </div>
      </div>
    )}
    {children}
  </motion.div>
);

const StatCard = ({ label, value, icon: Icon, color }: { label: string, value: string | number, icon: any, color: string }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="bg-white rounded-3xl p-6 shadow-lg border border-emerald-50 flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 text-center sm:text-left"
  >
    <div className={`p-4 rounded-2xl ${color} bg-opacity-10 text-${color.split('-')[1]}-600 shrink-0`}>
      <Icon size={32} />
    </div>
    <div>
      <p className="text-sm font-medium text-emerald-600/60 uppercase tracking-wider">{label}</p>
      <h4 className="text-2xl md:text-3xl font-black text-emerald-900">{value}</h4>
    </div>
  </motion.div>
);

const Toast = ({ message, type, onClose }: { message: string, type: 'success' | 'error', onClose: () => void }) => (
  <motion.div
    initial={{ opacity: 0, x: 100 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: 100 }}
    className={`fixed bottom-8 right-8 z-50 flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl ${
      type === 'success' ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
    }`}
  >
    {type === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
    <span className="font-medium">{message}</span>
    <button onClick={onClose} className="ml-4 hover:opacity-70"><X size={16} /></button>
  </motion.div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1200);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    // Close sidebar on mobile when section changes
    if (windowWidth < 1024) {
      setIsSidebarOpen(false);
    }
  }, [activeSection, windowWidth]);

  useEffect(() => {
    // Open sidebar by default on desktop
    if (windowWidth >= 1024) {
      setIsSidebarOpen(true);
    } else {
      setIsSidebarOpen(false);
    }
  }, [windowWidth]);

  useEffect(() => {
    if (isSidebarOpen && windowWidth < 1024) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isSidebarOpen, windowWidth]);
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Search States
  const [searchRoll, setSearchRoll] = useState('');
  const [searchClass, setSearchClass] = useState('');
  const [foundResult, setFoundResult] = useState<Result | null>(null);
  const [searching, setSearching] = useState(false);

  // Section-specific States
  const [announcementIsAdding, setAnnouncementIsAdding] = useState(false);
  const [announcementEditingId, setAnnouncementEditingId] = useState<string | null>(null);
  const [studentIsAdding, setStudentIsAdding] = useState(false);
  const [studentEditingId, setStudentEditingId] = useState<string | null>(null);
  const [studentSearch, setStudentSearch] = useState('');
  const [resultIsAdding, setResultIsAdding] = useState(false);
  const [staffIsAdding, setStaffIsAdding] = useState(false);
  const [staffEditingId, setStaffEditingId] = useState<string | null>(null);
  const [committeeIsAdding, setCommitteeIsAdding] = useState(false);
  const [committeeEditingId, setCommitteeEditingId] = useState<string | null>(null);
  const [selectedClassForResult, setSelectedClassForResult] = useState('');

  // Data States
  const [students, setStudents] = useState<Student[]>([]);
  const [staff, setStaff] = useState<Staff[]>([]);
  const [committee, setCommittee] = useState<Committee[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [details, setDetails] = useState<MadrasaDetails>({
    name_ar: 'مدرسة منار الهدى الثانوية العليا كادوغالور',
    name_en: 'Manar al-Huda Higher Secondary Madrasa, Kadugallur',
    address: 'Kadugallur, Kerala, India',
    contact: '+91 9876543210',
    classes: [
      { name: '1', subjects: ['Quran', 'Fiqh', 'Aqeedah', 'Arabic', 'History'] },
      { name: '2', subjects: ['Quran', 'Fiqh', 'Aqeedah', 'Arabic', 'History'] },
      { name: '3', subjects: ['Quran', 'Fiqh', 'Aqeedah', 'Arabic', 'History'] },
      { name: '4', subjects: ['Quran', 'Fiqh', 'Aqeedah', 'Arabic', 'History'] },
      { name: '5', subjects: ['Quran', 'Fiqh', 'Aqeedah', 'Arabic', 'History'] },
    ]
  });

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  // Real-time Data Listeners
  useEffect(() => {
    if (!user) return;

    const unsubStudents = onSnapshot(collection(db, 'students'), (snapshot) => {
      setStudents(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Student)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'students'));

    const unsubStaff = onSnapshot(collection(db, 'staff'), (snapshot) => {
      setStaff(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Staff)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'staff'));

    const unsubCommittee = onSnapshot(collection(db, 'committee'), (snapshot) => {
      setCommittee(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Committee)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'committee'));

    const unsubAnnouncements = onSnapshot(collection(db, 'announcements'), (snapshot) => {
      setAnnouncements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Announcement)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'announcements'));

    const unsubDetails = onSnapshot(doc(db, 'madrasa_details', 'main'), (doc) => {
      if (doc.exists()) {
        const data = doc.data() as MadrasaDetails;
        setDetails({
          ...data,
          classes: data.classes || []
        });
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, 'madrasa_details/main'));

    return () => {
      unsubStudents();
      unsubStaff();
      unsubCommittee();
      unsubAnnouncements();
      unsubDetails();
    };
  }, [user]);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      showToast('Welcome back, Admin!');
      setActiveSection('home');
    } catch (error) {
      showToast('Login failed. Please try again.', 'error');
    }
  };

  const handleEmailLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginError(null);
    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    try {
      await signInWithEmailAndPassword(auth, email, password);
      showToast('Welcome back, Admin!');
      setActiveSection('home');
    } catch (error: any) {
      if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        setLoginError('Username or password is incorrect');
      } else {
        setLoginError('Login failed. Please try again.');
      }
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      showToast('Logged out successfully');
      setActiveSection('home');
    } catch (error) {
      showToast('Logout failed', 'error');
    }
  };

  // --- Section Renderers ---

  const renderClassesManagement = () => {
    if (!isAdmin) return null;

    const handleAddClass = () => {
      const newClasses = [...(details.classes || []), { name: '', subjects: [] }];
      setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
    };

    const handleRemoveClass = (index: number) => {
      const newClasses = (details.classes || []).filter((_, i) => i !== index);
      setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
    };

    const handleUpdateClass = (index: number, name: string) => {
      const newClasses = [...(details.classes || [])];
      if (newClasses[index]) {
        newClasses[index].name = name;
        setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
      }
    };

    const handleUpdateClassTeacher = (index: number, teacher: string) => {
      const newClasses = [...(details.classes || [])];
      if (newClasses[index]) {
        newClasses[index].class_teacher = teacher;
        setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
      }
    };

    const handleAddSubject = (classIndex: number) => {
      const newClasses = [...(details.classes || [])];
      if (newClasses[classIndex]) {
        if (!newClasses[classIndex].subjects) newClasses[classIndex].subjects = [];
        newClasses[classIndex].subjects.push('');
        setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
      }
    };

    const handleRemoveSubject = (classIndex: number, subjectIndex: number) => {
      const newClasses = [...(details.classes || [])];
      if (newClasses[classIndex] && newClasses[classIndex].subjects) {
        newClasses[classIndex].subjects = newClasses[classIndex].subjects.filter((_, i) => i !== subjectIndex);
        setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
      }
    };

    const handleUpdateSubject = (classIndex: number, subjectIndex: number, value: string) => {
      const newClasses = [...(details.classes || [])];
      if (newClasses[classIndex] && newClasses[classIndex].subjects) {
        newClasses[classIndex].subjects[subjectIndex] = value;
        setDoc(doc(db, 'madrasa_details', 'main'), { classes: newClasses }, { merge: true });
      }
    };

    return (
      <Card title="Classes & Subjects Management" icon={Settings}>
        <div className="space-y-6">
          <p className="text-sm text-emerald-600/70">Manage the classes and subjects offered by the madrasa. This will update the result entry forms.</p>
          {(details.classes || []).map((cls, cIdx) => (
            <div key={cIdx} className="p-4 md:p-6 bg-emerald-50 rounded-2xl md:rounded-3xl border border-emerald-100 space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 w-full sm:w-auto">
                  <label className="text-sm font-bold text-emerald-900 shrink-0">Class Name:</label>
                  <input 
                    value={cls.name} 
                    onChange={(e) => handleUpdateClass(cIdx, e.target.value)}
                    className="w-full sm:w-48 px-4 py-2 rounded-xl border border-emerald-200 focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                    placeholder="e.g. 1, 2, 10th..."
                  />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 w-full sm:w-auto">
                  <label className="text-sm font-bold text-emerald-900 shrink-0">Class Teacher:</label>
                  <select 
                    value={cls.class_teacher || ''} 
                    onChange={(e) => handleUpdateClassTeacher(cIdx, e.target.value)}
                    className="w-full sm:w-48 px-4 py-2 rounded-xl border border-emerald-200 focus:ring-2 focus:ring-emerald-500 outline-none bg-white text-sm"
                  >
                    <option value="">Select Teacher...</option>
                    {staff.map(s => (
                      <option key={s.id} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <button onClick={() => handleRemoveClass(cIdx)} className="p-2 text-rose-400 hover:text-rose-600 self-end sm:self-auto">
                  <Trash2 size={20} />
                </button>
              </div>
              
              <div className="space-y-3">
                <label className="text-sm font-bold text-emerald-900 block">Subjects:</label>
                <div className="flex flex-wrap gap-2">
                  {(cls.subjects || []).map((sub, sIdx) => (
                    <div key={sIdx} className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-emerald-200 shadow-sm">
                      <input 
                        value={sub} 
                        onChange={(e) => handleUpdateSubject(cIdx, sIdx, e.target.value)}
                        className="bg-transparent text-sm font-medium text-emerald-900 outline-none w-20 md:w-24"
                      />
                      <button onClick={() => handleRemoveSubject(cIdx, sIdx)} className="text-rose-400 hover:text-rose-600">
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  <button 
                    onClick={() => handleAddSubject(cIdx)}
                    className="flex items-center gap-1 px-4 py-2 bg-emerald-900 text-white rounded-full text-xs font-bold hover:bg-emerald-800 transition-colors"
                  >
                    <Plus size={14} /> Add Subject
                  </button>
                </div>
              </div>
            </div>
          ))}
          <button 
            onClick={handleAddClass}
            className="w-full py-4 border-2 border-dashed border-emerald-200 rounded-3xl text-emerald-600 font-bold hover:bg-emerald-50 transition-all flex items-center justify-center gap-2"
          >
            <Plus size={20} /> Add New Class
          </button>
        </div>
      </Card>
    );
  };

  const handleNavClick = (section: string) => {
    setActiveSection(section);
    if (windowWidth < 1024) setIsSidebarOpen(false);
  };

  const renderHome = () => (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard label="Total Students" value={students.length} icon={Users} color="bg-blue-500" />
        <StatCard label="Staff Members" value={staff.length} icon={GraduationCap} color="bg-emerald-500" />
        <StatCard label="Committee" value={committee.length} icon={UserPlus} color="bg-amber-500" />
        <StatCard label="Announcements" value={announcements.length} icon={Bell} color="bg-rose-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card title="Latest Announcements" icon={Bell}>
          <div className="space-y-4">
            {announcements.slice(0, 3).map((ann) => (
              <div key={ann.id} className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100 flex gap-4">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm shrink-0">
                  <Bell size={20} />
                </div>
                <div>
                  <h5 className="font-bold text-emerald-900">{ann.title}</h5>
                  <p className="text-sm text-emerald-600/70 line-clamp-2">{ann.message}</p>
                  <span className="text-[10px] uppercase font-bold text-emerald-400 mt-2 block">{ann.date}</span>
                </div>
              </div>
            ))}
            {announcements.length === 0 && (
              <div className="text-center py-8 text-emerald-300">No announcements yet.</div>
            )}
          </div>
        </Card>

        <Card title="Quick Search Result" icon={Search}>
          <div className="space-y-6">
            <p className="text-sm text-emerald-600/70">Quickly check public exam results by roll number.</p>
            <form className="flex gap-3" onSubmit={(e) => {
              e.preventDefault();
              setActiveSection('results');
            }}>
              <input 
                type="text" 
                value={searchRoll}
                onChange={(e) => setSearchRoll(e.target.value)}
                placeholder="Enter Roll Number..." 
                className="flex-1 px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              />
              <button type="submit" className="px-6 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-colors">
                Search
              </button>
            </form>
          </div>
        </Card>
      </div>
    </div>
  );

  const renderBasicDetails = () => {
    if (!isAdmin) return null;
    return (
      <Card title="Madrasa Basic Details" icon={Info}>
      <form className="grid grid-cols-1 md:grid-cols-2 gap-6" onSubmit={(e) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const data = {
          name_ar: formData.get('name_ar') as string,
          name_en: formData.get('name_en') as string,
          address: formData.get('address') as string,
          contact: formData.get('contact') as string,
        };
        setDoc(doc(db, 'madrasa_details', 'main'), data, { merge: true })
          .then(() => showToast('Details updated successfully'))
          .catch(err => handleFirestoreError(err, OperationType.WRITE, 'madrasa_details/main'));
      }}>
        <div className="space-y-2">
          <label className="text-sm font-bold text-emerald-900">Arabic Name</label>
          <input name="name_ar" defaultValue={details.name_ar} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" dir="rtl" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold text-emerald-900">English Name</label>
          <input name="name_en" defaultValue={details.name_en} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
        </div>
        <div className="space-y-2 md:col-span-2">
          <label className="text-sm font-bold text-emerald-900">Address</label>
          <textarea name="address" defaultValue={details.address} rows={3} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold text-emerald-900">Contact Info</label>
          <input name="contact" defaultValue={details.contact} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
        </div>
        <div className="md:col-span-2 flex justify-end">
          <button type="submit" className="flex items-center gap-2 px-8 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all">
            <Save size={20} /> Save Changes
          </button>
        </div>
      </form>
      </Card>
    );
  };

  const renderAnnouncements = () => {
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const data = {
        title: formData.get('title') as string,
        message: formData.get('message') as string,
        date: new Date().toLocaleDateString(),
        uid: user?.uid
      };

      try {
        if (announcementEditingId) {
          await updateDoc(doc(db, 'announcements', announcementEditingId), data);
          showToast('Announcement updated');
        } else {
          await setDoc(doc(collection(db, 'announcements')), data);
          showToast('Announcement posted');
        }
        setAnnouncementIsAdding(false);
        setAnnouncementEditingId(null);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'announcements');
      }
    };

    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-3xl font-black text-emerald-900">Announcements</h2>
          {isAdmin && (
            <button 
              onClick={() => setAnnouncementIsAdding(true)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all"
            >
              <Plus size={20} /> Post New
            </button>
          )}
        </div>

        <AnimatePresence>
          {announcementIsAdding && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white p-8 rounded-[2.5rem] shadow-2xl border border-emerald-100"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold text-emerald-900">{announcementEditingId ? 'Edit' : 'New'} Announcement</h3>
                  <button type="button" onClick={() => { setAnnouncementIsAdding(false); setAnnouncementEditingId(null); }} className="text-emerald-400 hover:text-emerald-600"><X size={24} /></button>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-emerald-900">Title</label>
                  <input name="title" required defaultValue={announcementEditingId ? announcements.find(a => a.id === announcementEditingId)?.title : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-emerald-900">Message</label>
                  <textarea name="message" required rows={4} defaultValue={announcementEditingId ? announcements.find(a => a.id === announcementEditingId)?.message : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <button type="submit" className="w-full py-4 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all">
                  {announcementEditingId ? 'Update' : 'Post'} Announcement
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {announcements.map((ann) => (
            <Card key={ann.id}>
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-emerald-50 rounded-2xl text-emerald-600"><Bell size={24} /></div>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button onClick={() => { setAnnouncementEditingId(ann.id); setAnnouncementIsAdding(true); }} className="p-2 text-emerald-400 hover:text-emerald-600"><Edit2 size={18} /></button>
                    <button onClick={() => deleteDoc(doc(db, 'announcements', ann.id))} className="p-2 text-rose-400 hover:text-rose-600"><Trash2 size={18} /></button>
                  </div>
                )}
              </div>
              <h4 className="text-xl font-bold text-emerald-900 mb-2">{ann.title}</h4>
              <p className="text-emerald-600/70 mb-4">{ann.message}</p>
              <div className="flex items-center justify-between pt-4 border-t border-emerald-50">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">{ann.date}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  const renderStudentsCount = () => {
    const classCounts = students.reduce((acc, s) => {
      acc[s.class] = (acc[s.class] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return (
      <div className="space-y-8">
        <h2 className="text-3xl font-black text-emerald-900">Students Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard label="Total Strength" value={students.length} icon={Users} color="bg-emerald-500" />
          <StatCard label="Active Classes" value={Object.keys(classCounts).length} icon={LayoutDashboard} color="bg-blue-500" />
          <StatCard label="Average per Class" value={students.length ? Math.round(students.length / Object.keys(classCounts).length) : 0} icon={ClipboardList} color="bg-amber-500" />
        </div>
        
        <Card title="Class-wise Breakdown" icon={LayoutDashboard}>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {(details.classes || []).map((cls) => (
              <div key={cls.name} className="p-6 bg-emerald-50 rounded-[2rem] border border-emerald-100 text-center space-y-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">Class</span>
                <h5 className="text-2xl font-black text-emerald-900">{cls.name}</h5>
                <div className="text-sm font-bold text-emerald-600">{(classCounts[cls.name] || 0)} Students</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    );
  };

  const exportToPDF = (data: any[], title: string, columns: string[], keys: string[]) => {
    const doc = new jsPDF();
    doc.text(title, 14, 15);
    autoTable(doc, {
      startY: 20,
      head: [columns],
      body: data.map(item => keys.map(key => item[key])),
      theme: 'grid',
      headStyles: { fillColor: [6, 78, 59] } // emerald-900
    });
    doc.save(`${title.replace(/\s+/g, '_')}.pdf`);
    showToast(`${title} exported successfully!`);
  };

  const renderManageStudents = () => {
    if (!isAdmin) return null;

    const filteredStudents = students.filter(s => 
      s.name.toLowerCase().includes(studentSearch.toLowerCase()) || 
      s.roll_no.includes(studentSearch)
    );

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const data = {
        name: formData.get('name') as string,
        father_name: formData.get('father_name') as string,
        class: formData.get('class') as string,
        roll_no: formData.get('roll_no') as string,
        uid: user?.uid
      };
      try {
        if (studentEditingId) {
          await updateDoc(doc(db, 'students', studentEditingId), data);
          showToast('Student updated successfully');
        } else {
          await setDoc(doc(collection(db, 'students')), data);
          showToast('Student added successfully');
        }
        setStudentIsAdding(false);
        setStudentEditingId(null);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'students');
      }
    };

    return (
      <div className="space-y-8">
        {renderClassesManagement()}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <h2 className="text-3xl font-black text-emerald-900">Manage Students</h2>
            <button 
              onClick={() => exportToPDF(students, 'Student List', ['Name', 'Father Name', 'Class', 'Roll No'], ['name', 'father_name', 'class', 'roll_no'])}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-900 rounded-xl font-bold hover:bg-emerald-200 transition-all text-sm"
            >
              <Download size={16} /> Export PDF
            </button>
          </div>
          <div className="flex flex-col sm:flex-row w-full md:w-auto gap-3">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400" size={18} />
              <input 
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search students..." 
                className="w-full pl-12 pr-4 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>
            <button 
              onClick={() => setStudentIsAdding(true)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all"
            >
              <Plus size={20} /> Add Student
            </button>
          </div>
        </div>

        <AnimatePresence>
          {studentIsAdding && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white p-8 rounded-[2.5rem] shadow-2xl border border-emerald-100"
            >
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex justify-between items-center md:col-span-2">
                  <h3 className="text-xl font-bold text-emerald-900">{studentEditingId ? 'Edit' : 'Add New'} Student</h3>
                  <button type="button" onClick={() => { setStudentIsAdding(false); setStudentEditingId(null); }} className="text-emerald-400 hover:text-emerald-600"><X size={24} /></button>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-emerald-900">Full Name</label>
                  <input name="name" required defaultValue={studentEditingId ? students.find(s => s.id === studentEditingId)?.name : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-emerald-900">Father's Name</label>
                  <input name="father_name" required defaultValue={studentEditingId ? students.find(s => s.id === studentEditingId)?.father_name : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-emerald-900">Class</label>
                  <select 
                    name="class" 
                    required 
                    defaultValue={studentEditingId ? students.find(s => s.id === studentEditingId)?.class : ''} 
                    className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    <option value="">Choose Class...</option>
                    {(details.classes || []).map(cls => (
                      <option key={cls.name} value={cls.name}>{cls.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-emerald-900">Roll Number</label>
                  <input name="roll_no" required defaultValue={studentEditingId ? students.find(s => s.id === studentEditingId)?.roll_no : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                </div>
                <button type="submit" className="md:col-span-2 py-4 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all">
                  {studentEditingId ? 'Update' : 'Register'} Student
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="bg-white rounded-[2.5rem] shadow-xl border border-emerald-50 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-emerald-50/50">
                  <th className="px-8 py-6 text-xs font-bold text-emerald-400 uppercase tracking-widest">Roll No</th>
                  <th className="px-8 py-6 text-xs font-bold text-emerald-400 uppercase tracking-widest">Name</th>
                  <th className="px-8 py-6 text-xs font-bold text-emerald-400 uppercase tracking-widest">Father's Name</th>
                  <th className="px-8 py-6 text-xs font-bold text-emerald-400 uppercase tracking-widest">Class</th>
                  <th className="px-8 py-6 text-xs font-bold text-emerald-400 uppercase tracking-widest text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-emerald-50">
                {filteredStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-emerald-50/30 transition-colors">
                    <td className="px-8 py-6 font-mono font-bold text-emerald-900">{s.roll_no}</td>
                    <td className="px-8 py-6 font-bold text-emerald-900">{s.name}</td>
                    <td className="px-8 py-6 text-emerald-600/70">{s.father_name}</td>
                    <td className="px-8 py-6">
                      <span className="px-4 py-1.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-black">{s.class}</span>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => { setStudentEditingId(s.id); setStudentIsAdding(true); }} className="p-2 text-emerald-400 hover:text-emerald-600"><Edit2 size={18} /></button>
                        <button onClick={() => deleteDoc(doc(db, 'students', s.id))} className="p-2 text-rose-400 hover:text-rose-600"><Trash2 size={18} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredStudents.length === 0 && (
            <div className="text-center py-20 text-emerald-300">
              <Users size={48} className="mx-auto mb-4 opacity-20" />
              <p>No students found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderPublicResult = () => {
    const handleDownloadPDF = async () => {
      const element = document.getElementById('result-card');
      if (!element) return;
      
      try {
        const canvas = await html2canvas(element, {
          scale: 2,
          useCORS: true,
          backgroundColor: '#ffffff'
        });
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`Result_${foundResult?.roll_no}_${foundResult?.student_name}.pdf`);
        showToast('PDF downloaded successfully!');
      } catch (error) {
        console.error('PDF export failed:', error);
        showToast('Failed to export PDF', 'error');
      }
    };

    const handleShareResult = async () => {
      if (!foundResult) return;
      const shareData = {
        title: 'Exam Result - Manar al-Huda',
        text: `Check out the exam result for ${foundResult.student_name} (Roll No: ${foundResult.roll_no}). Grade: ${foundResult.grade}, Total: ${foundResult.total}`,
        url: window.location.href
      };

      try {
        if (navigator.share) {
          await navigator.share(shareData);
        } else {
          await navigator.clipboard.writeText(`${shareData.text}\n${shareData.url}`);
          showToast('Result link copied to clipboard!');
        }
      } catch (error) {
        console.error('Sharing failed:', error);
      }
    };

    const handleSearch = async () => {
      if (!searchRoll || !searchClass) return showToast('Please enter both Class and Roll No', 'error');
      setSearching(true);
      try {
        const q = query(collection(db, 'results'), where('roll_no', '==', searchRoll), where('class', '==', searchClass));
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          setFoundResult({ id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Result);
        } else {
          setFoundResult(null);
          showToast('No result found for this roll number', 'error');
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, 'results');
      } finally {
        setSearching(false);
      }
    };

    const handleAddResult = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const roll = formData.get('roll_no') as string;
      const cls = formData.get('class') as string;
      const maxMarksPerSubject = parseInt(formData.get('max_marks_per_subject') as string) || 100;
      const daysPresent = parseInt(formData.get('days_present') as string) || 0;
      const totalDays = parseInt(formData.get('total_days') as string) || 1;
      
      const marks: Record<string, number> = {};
      const subjects = (details.classes || []).find(c => c.name === cls)?.subjects || [];
      let total = 0;
      subjects.forEach(sub => {
        const m = parseInt(formData.get(sub) as string) || 0;
        marks[sub] = m;
        total += m;
      });

      const student = students.find(s => s.roll_no === roll && s.class === cls);
      if (!student) return showToast('Student not found with this Roll No and Class', 'error');

      const maxPossible = subjects.length * maxMarksPerSubject;
      const percentage = maxPossible > 0 ? (total / maxPossible) * 100 : 0;
      const attendance = totalDays > 0 ? ((daysPresent / totalDays) * 100).toFixed(1) + '%' : '0%';
      const grade = percentage >= 90 ? 'A+' : percentage >= 80 ? 'A' : percentage >= 70 ? 'B' : 'C';

      const data = {
        student_id: student.id,
        student_name: student.name,
        father_name: student.father_name,
        class: cls,
        roll_no: roll,
        marks,
        total,
        grade,
        max_marks: maxPossible,
        attendance,
        percentage: parseFloat(percentage.toFixed(2)),
        uid: user?.uid
      };

      try {
        await setDoc(doc(collection(db, 'results')), data);
        showToast('Result added successfully');
        setResultIsAdding(false);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'results');
      }
    };

    return (
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <div className="text-left space-y-2">
            <h2 className="text-4xl font-black text-emerald-900">Public Exam Results</h2>
            <p className="text-emerald-600/70">Enter credentials below to view mark sheet.</p>
          </div>
          {isAdmin && (
            <button 
              onClick={() => setResultIsAdding(true)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all"
            >
              <Plus size={20} /> Add Result
            </button>
          )}
        </div>

        <AnimatePresence>
          {resultIsAdding && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white p-8 rounded-[2.5rem] shadow-2xl border border-emerald-100"
            >
              <form onSubmit={handleAddResult} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold text-emerald-900">Add Student Result</h3>
                  <button type="button" onClick={() => setResultIsAdding(false)} className="text-emerald-400 hover:text-emerald-600"><X size={24} /></button>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Class</label>
                    <select 
                      name="class" 
                      required 
                      value={selectedClassForResult}
                      onChange={(e) => setSelectedClassForResult(e.target.value)}
                      className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                    >
                      <option value="">Choose Class...</option>
                      {(details.classes || []).map(cls => (
                        <option key={cls.name} value={cls.name}>{cls.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Roll Number</label>
                    <input name="roll_no" required className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Max Marks per Subject</label>
                    <input name="max_marks_per_subject" type="number" required defaultValue="100" className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Total Days</label>
                    <input name="total_days" type="number" required defaultValue="200" className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Days Present</label>
                    <input name="days_present" type="number" required defaultValue="180" className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {details.classes.find(c => c.name === selectedClassForResult)?.subjects?.map(sub => (
                      <div key={sub} className="space-y-2">
                        <label className="text-sm font-bold text-emerald-900">{sub} Marks</label>
                        <input name={sub} type="number" max="100" required className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                      </div>
                    ))}
                  </div>
                </div>
                <button type="submit" className="w-full py-4 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all">
                  Save Result
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <Card>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-emerald-900">Select Class</label>
              <select 
                value={searchClass}
                onChange={(e) => setSearchClass(e.target.value)}
                className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
              >
                <option value="">Choose Class...</option>
                {(details.classes || []).map(cls => (
                  <option key={cls.name} value={cls.name}>{cls.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-emerald-900">Roll Number</label>
              <input 
                value={searchRoll}
                onChange={(e) => setSearchRoll(e.target.value)}
                placeholder="e.g. 10245" 
                className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>
            <div className="flex items-end">
              <button 
                onClick={handleSearch}
                disabled={searching}
                className="w-full py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all flex items-center justify-center gap-2"
              >
                {searching ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Search size={20} />}
                Search Result
              </button>
            </div>
          </div>
        </Card>

        <AnimatePresence>
          {foundResult && (
            <motion.div 
              id="result-card"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-6 md:p-12 rounded-2xl md:rounded-[3rem] shadow-2xl border-4 border-emerald-900 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-emerald-900" />
              <div className="text-center space-y-4 md:space-y-6 mb-8 md:mb-12">
                <h3 className="text-2xl md:text-3xl font-arabic text-emerald-900">{details.name_ar}</h3>
                <div className="inline-block px-6 md:px-8 py-2 bg-emerald-900 text-gold-400 rounded-full text-xs md:text-sm font-black uppercase tracking-widest">
                  Official Mark Sheet
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 md:gap-8 mb-8 md:mb-12">
                <div className="space-y-1">
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase">Student Name</p>
                  <p className="text-lg md:text-xl font-black text-emerald-900">{foundResult.student_name}</p>
                </div>
                <div className="space-y-1 sm:text-center">
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase">Roll Number</p>
                  <p className="text-lg md:text-xl font-black text-emerald-900">{foundResult.roll_no}</p>
                </div>
                <div className="space-y-1 sm:text-right">
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase">Attendance</p>
                  <p className="text-lg md:text-xl font-black text-emerald-900">{foundResult.attendance || 'N/A'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase">Father's Name</p>
                  <p className="text-base md:text-lg font-bold text-emerald-800">{foundResult.father_name}</p>
                </div>
                <div className="space-y-1 sm:text-center">
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase">Class</p>
                  <p className="text-base md:text-lg font-bold text-emerald-800">{foundResult.class}</p>
                </div>
                <div className="space-y-1 sm:text-right">
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase">Percentage</p>
                  <p className="text-base md:text-lg font-bold text-emerald-800">{foundResult.percentage ?? '0'}%</p>
                </div>
              </div>

              <div className="border-2 border-emerald-50 rounded-2xl md:rounded-3xl overflow-hidden mb-8 md:mb-12">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-emerald-50">
                      <tr>
                        <th className="px-4 md:px-6 py-3 md:py-4 text-left text-[10px] md:text-xs font-bold text-emerald-900 uppercase">Subject</th>
                        <th className="px-4 md:px-6 py-3 md:py-4 text-center text-[10px] md:text-xs font-bold text-emerald-900 uppercase">Max Marks</th>
                        <th className="px-4 md:px-6 py-3 md:py-4 text-right text-[10px] md:text-xs font-bold text-emerald-900 uppercase">Obtained</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-emerald-50">
                      {Object.entries(foundResult.marks || {}).map(([sub, mark]) => {
                        const subjectCount = Object.keys(foundResult.marks).length;
                        const maxPerSub = (subjectCount > 0 && foundResult.max_marks) ? Math.round(foundResult.max_marks / subjectCount) : 100;
                        return (
                          <tr key={sub}>
                            <td className="px-4 md:px-6 py-3 md:py-4 font-bold text-emerald-800 text-sm md:text-base">{sub}</td>
                            <td className="px-4 md:px-6 py-3 md:py-4 text-center font-mono text-emerald-600 text-sm md:text-base">{maxPerSub}</td>
                            <td className="px-4 md:px-6 py-3 md:py-4 text-right font-mono font-bold text-emerald-900 text-sm md:text-base">{mark}</td>
                          </tr>
                        );
                      })}
                      <tr className="bg-emerald-900 text-white">
                        <td className="px-4 md:px-6 py-4 md:py-6 font-black text-base md:text-lg uppercase">Total</td>
                        <td className="px-4 md:px-6 py-4 md:py-6 text-center font-black text-lg md:text-xl">{foundResult.max_marks || '0'}</td>
                        <td className="px-4 md:px-6 py-4 md:py-6 text-right font-black text-xl md:text-2xl">{foundResult.total || '0'}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-center">
                  <div className="w-20 h-20 md:w-24 md:h-24 rounded-full border-4 border-emerald-900 flex items-center justify-center">
                    <span className="text-3xl md:text-4xl font-black text-emerald-900">{foundResult.grade}</span>
                  </div>
                  <p className="text-[10px] md:text-xs font-bold text-emerald-400 uppercase mt-2">Overall Grade</p>
                </div>
                <div className="flex flex-wrap justify-center gap-3 w-full sm:w-auto">
                  <button 
                    onClick={handleDownloadPDF}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-emerald-900 text-white rounded-xl font-bold hover:bg-emerald-800 transition-all shadow-lg"
                  >
                    <Download size={18} /> PDF
                  </button>
                  <button 
                    onClick={() => window.print()}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-emerald-100 text-emerald-900 rounded-xl font-bold hover:bg-emerald-200 transition-all border border-emerald-200"
                  >
                    <Eye size={18} /> Print
                  </button>
                  <button 
                    onClick={handleShareResult}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-gold-400 text-emerald-950 rounded-xl font-bold hover:bg-gold-500 transition-all shadow-lg"
                  >
                    <Plus size={18} className="rotate-45" /> Share
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const renderStaff = () => {
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const data = {
        name: formData.get('name') as string,
        role: formData.get('role') as string,
        contact: formData.get('contact') as string,
        uid: user?.uid
      };

      try {
        if (staffEditingId) {
          await updateDoc(doc(db, 'staff', staffEditingId), data);
          showToast('Staff updated');
        } else {
          await setDoc(doc(collection(db, 'staff')), data);
          showToast('Staff added');
        }
        setStaffIsAdding(false);
        setStaffEditingId(null);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'staff');
      }
    };

    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-4">
            <h2 className="text-3xl font-black text-emerald-900">Muallim Staff</h2>
            <button 
              onClick={() => exportToPDF(staff, 'Staff List', ['Name', 'Role', 'Contact'], ['name', 'role', 'contact'])}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-900 rounded-xl font-bold hover:bg-emerald-200 transition-all text-sm"
            >
              <Download size={16} /> Export
            </button>
          </div>
          {isAdmin && (
            <button 
              onClick={() => setStaffIsAdding(true)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all"
            >
              <Plus size={20} /> Add Staff
            </button>
          )}
        </div>

        <AnimatePresence>
          {staffIsAdding && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white p-8 rounded-[2.5rem] shadow-2xl border border-emerald-100"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold text-emerald-900">{staffEditingId ? 'Edit' : 'New'} Staff Member</h3>
                  <button type="button" onClick={() => { setStaffIsAdding(false); setStaffEditingId(null); }} className="text-emerald-400 hover:text-emerald-600"><X size={24} /></button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Name</label>
                    <input name="name" required defaultValue={staffEditingId ? staff.find(s => s.id === staffEditingId)?.name : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Role</label>
                    <input name="role" required defaultValue={staffEditingId ? staff.find(s => s.id === staffEditingId)?.role : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-sm font-bold text-emerald-900">Contact</label>
                    <input name="contact" required defaultValue={staffEditingId ? staff.find(s => s.id === staffEditingId)?.contact : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                </div>
                <button type="submit" className="w-full py-4 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all">
                  {staffEditingId ? 'Update' : 'Add'} Staff Member
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {staff.map((s) => (
            <Card key={s.id} title={s.name} subtitle={s.role} icon={GraduationCap}>
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-emerald-50">
                <span className="text-sm font-bold text-emerald-600">{s.contact}</span>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button onClick={() => { setStaffEditingId(s.id); setStaffIsAdding(true); }} className="text-emerald-400 hover:text-emerald-600">
                      <Edit2 size={18} />
                    </button>
                    <button onClick={() => deleteDoc(doc(db, 'staff', s.id))} className="text-rose-400 hover:text-rose-600">
                      <Trash2 size={18} />
                    </button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  const renderCommittee = () => {
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const data = {
        name: formData.get('name') as string,
        role: formData.get('role') as string,
        contact: formData.get('contact') as string,
        uid: user?.uid
      };

      try {
        if (committeeEditingId) {
          await updateDoc(doc(db, 'committee', committeeEditingId), data);
          showToast('Member updated');
        } else {
          await setDoc(doc(collection(db, 'committee')), data);
          showToast('Member added');
        }
        setCommitteeIsAdding(false);
        setCommitteeEditingId(null);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'committee');
      }
    };

    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-4">
            <h2 className="text-3xl font-black text-emerald-900">Madrasa Committee</h2>
            <button 
              onClick={() => exportToPDF(committee, 'Committee List', ['Name', 'Role', 'Contact'], ['name', 'role', 'contact'])}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-900 rounded-xl font-bold hover:bg-emerald-200 transition-all text-sm"
            >
              <Download size={16} /> Export
            </button>
          </div>
          {isAdmin && (
            <button 
              onClick={() => setCommitteeIsAdding(true)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all"
            >
              <Plus size={20} /> Add Member
            </button>
          )}
        </div>

        <AnimatePresence>
          {committeeIsAdding && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white p-8 rounded-[2.5rem] shadow-2xl border border-emerald-100"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold text-emerald-900">{committeeEditingId ? 'Edit' : 'New'} Committee Member</h3>
                  <button type="button" onClick={() => { setCommitteeIsAdding(false); setCommitteeEditingId(null); }} className="text-emerald-400 hover:text-emerald-600"><X size={24} /></button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Name</label>
                    <input name="name" required defaultValue={committeeEditingId ? committee.find(c => c.id === committeeEditingId)?.name : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-emerald-900">Role</label>
                    <input name="role" required defaultValue={committeeEditingId ? committee.find(c => c.id === committeeEditingId)?.role : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-sm font-bold text-emerald-900">Contact</label>
                    <input name="contact" required defaultValue={committeeEditingId ? committee.find(c => c.id === committeeEditingId)?.contact : ''} className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none" />
                  </div>
                </div>
                <button type="submit" className="w-full py-4 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all">
                  {committeeEditingId ? 'Update' : 'Add'} Member
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {committee.map((m) => (
            <Card key={m.id} title={m.name} subtitle={m.role} icon={UserPlus}>
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-emerald-50">
                <span className="text-sm font-bold text-emerald-600">{m.contact}</span>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button onClick={() => { setCommitteeEditingId(m.id); setCommitteeIsAdding(true); }} className="text-emerald-400 hover:text-emerald-600">
                      <Edit2 size={18} />
                    </button>
                    <button onClick={() => deleteDoc(doc(db, 'committee', m.id))} className="text-rose-400 hover:text-rose-600">
                      <Trash2 size={18} />
                    </button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  };
  const renderHelp = () => (
    <div className="max-w-3xl mx-auto space-y-8">
      <h2 className="text-3xl font-black text-emerald-900">Help & Support</h2>
      <div className="space-y-6">
        {[
          { q: "How to add a new student?", a: "Go to 'Manage Students' section and click on 'Add Student' button. Fill in the details and save." },
          { q: "How to update exam results?", a: "Currently, results are managed by the administrator. Go to 'Manage Students' to find a student and attach their result." },
          { q: "Can I change the Madrasa name?", a: "Yes, go to 'Basic Details' section to update the Arabic and English names of the institution." },
          { q: "Is the data secure?", a: "Yes, all data is stored securely on Firebase and protected by strict security rules." }
        ].map((item, i) => (
          <Card key={i} title={item.q}>
            <p className="text-emerald-600/70 leading-relaxed">{item.a}</p>
          </Card>
        ))}
      </div>
      <div className="p-8 bg-emerald-900 rounded-[2.5rem] text-white text-center space-y-4">
        <HelpCircle size={48} className="mx-auto text-gold-400" />
        <h3 className="text-xl font-bold">Still need help?</h3>
        <p className="text-emerald-100/70">Contact our technical support team at support@manaralhuda.edu</p>
      </div>
    </div>
  );

  const isAdmin = user?.email === 'mhmkgr868@gmail.com' || user?.email === 'mthwahace685@gmail.com';

  // --- Main Layout ---

  if (loading) {
    return (
      <div className="min-h-screen bg-emerald-50 flex items-center justify-center">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
          className="w-16 h-16 border-4 border-emerald-900 border-t-gold-400 rounded-full"
        />
      </div>
    );
  }

  const renderLoginScreen = () => (
    <div className="min-h-screen bg-emerald-950 flex items-center justify-center p-6">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1),transparent_50%)]" />
      </div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-white rounded-[3rem] p-12 shadow-2xl text-center space-y-8 relative z-10"
      >
        <div className="w-24 h-24 bg-emerald-900 rounded-3xl mx-auto flex items-center justify-center text-gold-400 shadow-xl rotate-12">
          <LayoutDashboard size={48} />
        </div>
        <div className="space-y-2">
          <h1 className="text-3xl font-arabic text-emerald-900 leading-tight">مدرسة منار الهدى</h1>
          <h2 className="text-xl font-bold text-emerald-800">Admin Portal</h2>
          <p className="text-emerald-600/60">Please sign in to manage your madrasa records.</p>
        </div>

        <form onSubmit={handleEmailLogin} className="space-y-4 text-left">
          {loginError && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-sm font-bold"
            >
              <AlertCircle size={18} />
              {loginError}
            </motion.div>
          )}
          <div className="space-y-1">
            <label className="text-xs font-bold text-emerald-900 uppercase tracking-wider ml-1">Email Address</label>
            <input 
              name="email" 
              type="email" 
              required 
              placeholder="admin@example.com"
              className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-emerald-900 uppercase tracking-wider ml-1">Password</label>
            <div className="relative">
              <input 
                name="password" 
                type={showPassword ? "text" : "password"} 
                required 
                placeholder="••••••••"
                className="w-full px-5 py-3 rounded-2xl border border-emerald-100 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-emerald-400 hover:text-emerald-600 transition-colors"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>
          <button 
            type="submit"
            className="w-full py-4 bg-emerald-900 text-white rounded-2xl font-bold hover:bg-emerald-800 transition-all shadow-lg hover:shadow-emerald-900/20"
          >
            Sign In
          </button>
        </form>

        <div className="flex items-center gap-4 py-2">
          <div className="h-px bg-emerald-100 flex-1" />
          <span className="text-xs font-bold text-emerald-300 uppercase tracking-widest">OR</span>
          <div className="h-px bg-emerald-100 flex-1" />
        </div>

        <button 
          onClick={handleLogin}
          className="w-full py-4 bg-white border-2 border-emerald-100 text-emerald-900 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-emerald-50 transition-all shadow-sm"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
          Continue with Google
        </button>
        <div className="pt-4 border-t border-emerald-50">
          <p className="text-xs text-emerald-400 font-bold uppercase tracking-widest">Authorized Personnel Only</p>
        </div>
        <button 
          onClick={() => setActiveSection('home')}
          className="text-emerald-600 font-bold hover:underline"
        >
          Back to Public View
        </button>
      </motion.div>
    </div>
  );

  if (activeSection === 'login' && !user) {
    return renderLoginScreen();
  }

  return (
    <div className="min-h-screen bg-[#f8faf9] flex">
      {/* Mobile Sidebar Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-emerald-950/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ 
          x: isSidebarOpen || windowWidth >= 1024 ? 0 : -300
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className={`bg-emerald-950 text-white flex-shrink-0 fixed lg:sticky top-0 h-screen z-50 flex flex-col w-[300px] overflow-y-auto ${(!isSidebarOpen && windowWidth < 1024) && 'pointer-events-none lg:pointer-events-auto'}`}
      >
        <div className="p-8 space-y-8 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-800 rounded-2xl flex items-center justify-center text-gold-400 shadow-lg">
              <LayoutDashboard size={24} />
            </div>
            <div>
              <h2 className="text-lg font-bold leading-tight">Manar al-Huda</h2>
              <p className="text-[10px] uppercase font-bold text-emerald-400 tracking-widest">Management v1.0</p>
            </div>
          </div>

          <nav className="space-y-2">
            <SidebarItem icon={Home} label="Home" active={activeSection === 'home'} onClick={() => handleNavClick('home')} />
            {isAdmin && <SidebarItem icon={Info} label="Basic Details" active={activeSection === 'details'} onClick={() => handleNavClick('details')} />}
            <SidebarItem icon={Bell} label="Announcements" active={activeSection === 'announcements'} onClick={() => handleNavClick('announcements')} />
            <SidebarItem icon={ClipboardList} label="Students Count" active={activeSection === 'count'} onClick={() => handleNavClick('count')} />
            <SidebarItem icon={UserPlus} label="Madrasa Committee" active={activeSection === 'committee'} onClick={() => handleNavClick('committee')} />
            <SidebarItem icon={GraduationCap} label="Muallim Staff" active={activeSection === 'staff'} onClick={() => handleNavClick('staff')} />
            <SidebarItem icon={CheckCircle2} label="Exam Results" active={activeSection === 'results'} onClick={() => handleNavClick('results')} />
            {isAdmin && <SidebarItem icon={Users} label="Manage Students" active={activeSection === 'students'} onClick={() => handleNavClick('students')} />}
            <SidebarItem icon={HelpCircle} label="Help" active={activeSection === 'help'} onClick={() => handleNavClick('help')} />
            <div className="pt-8">
              {isAdmin ? (
                <SidebarItem icon={LogOut} label="Logout" active={false} onClick={() => { handleLogout(); if (windowWidth < 1024) setIsSidebarOpen(false); }} />
              ) : (
                <SidebarItem icon={LogOut} label="Admin Login" active={activeSection === 'login'} onClick={() => handleNavClick('login')} />
              )}
            </div>
          </nav>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-emerald-900/50 to-transparent pointer-events-none" />
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-20 bg-white border-b border-emerald-50 px-8 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-emerald-900 hover:bg-emerald-50 rounded-xl lg:hidden">
              <Menu size={24} />
            </button>
            <h3 className="text-xl font-bold text-emerald-900 capitalize">{activeSection.replace('-', ' ')}</h3>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="hidden md:flex flex-col text-right">
              <span className="text-sm font-bold text-emerald-900">{user?.displayName || 'Guest Student'}</span>
              <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-widest">{isAdmin ? 'Administrator' : 'Public Access'}</span>
            </div>
            {user?.photoURL ? (
              <img src={user.photoURL} className="w-10 h-10 rounded-xl border-2 border-emerald-100 shadow-sm" alt="Profile" />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-emerald-50 border-2 border-emerald-100 flex items-center justify-center text-emerald-400">
                <Users size={20} />
              </div>
            )}
          </div>
        </header>

        {/* Content Area */}
        <div className="p-4 md:p-8 max-w-7xl mx-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {activeSection === 'home' && renderHome()}
              {activeSection === 'details' && renderBasicDetails()}
              {activeSection === 'announcements' && renderAnnouncements()}
              {activeSection === 'count' && renderStudentsCount()}
              {activeSection === 'students' && renderManageStudents()}
              {activeSection === 'results' && renderPublicResult()}
              {activeSection === 'help' && renderHelp()}
              {activeSection === 'staff' && renderStaff()}
              {activeSection === 'committee' && renderCommittee()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Toast */}
      <AnimatePresence>
        {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      </AnimatePresence>
    </div>
  );
}
